<footer>
	<section id="footer_in">
	
	
	<div id="footer_logo">
		<img src="/imgs/logo.png" alt="footer_logo" title="footer_logo" />
	</div>
	<div id="copyright">
		Copyright S Shop
	</div>
	</section>
</footer>