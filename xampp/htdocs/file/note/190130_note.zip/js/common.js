$(function(){
	$("#fr_bt").click(function(){
		$('#frn_cre').css('display','block');
	});
	$("#frn_set").click(function(){
		$('#frn_cre').css('display','none');
	});
});