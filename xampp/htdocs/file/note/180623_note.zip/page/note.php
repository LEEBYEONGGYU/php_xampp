<?php 

include "../include/db.php";
include "../include/header.php";
?>